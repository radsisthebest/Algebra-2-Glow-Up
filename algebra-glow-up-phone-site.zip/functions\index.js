const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret, defineString } = require("firebase-functions/params");
const admin = require("firebase-admin");

admin.initializeApp();

const db = admin.firestore();
const OPENAI_API_KEY = defineSecret("OPENAI_API_KEY");
const BASIC_MODEL = defineString("BASIC_OPENAI_MODEL", { default: "gpt-4.1-nano" });
const PREMIUM_MODEL = defineString("PREMIUM_OPENAI_MODEL", { default: "gpt-5.5" });

const ADMIN_EMAILS = new Set([
  "radhikatchandra@outlook.com",
  "radhikachandra809@gmail.com",
  "ranveer.chandra@gmail.com"
]);

function requireAuth(request) {
  if (!request.auth) throw new HttpsError("unauthenticated", "Please sign in first.");
  return request.auth;
}

function normalizedEmail(auth) {
  return String(auth.token.email || "").toLowerCase();
}

function isConfiguredAdmin(email) {
  return ADMIN_EMAILS.has(String(email || "").toLowerCase());
}

function todayKey(date = new Date()) {
  return date.toISOString().slice(0, 10);
}

async function getOrCreateUser(auth) {
  const uid = auth.uid;
  const email = normalizedEmail(auth);
  const ref = db.collection("users").doc(uid);
  const now = admin.firestore.FieldValue.serverTimestamp();
  const snap = await ref.get();
  const forcedPremium = isConfiguredAdmin(email);
  const existing = snap.exists ? snap.data() : {};
  const approvedPremium = forcedPremium
    || existing.accountType === "premium"
    || existing.premiumStatus === "approved"
    || existing.forcedPremium === true;
  const base = {
    uid,
    email,
    displayName: auth.token.name || "",
    provider: auth.token.firebase?.sign_in_provider || "unknown",
    admin: forcedPremium,
    accountType: approvedPremium ? "premium" : (existing.accountType || "basic"),
    premiumStatus: approvedPremium ? "approved" : (existing.premiumStatus || "none"),
    forcedPremium,
    lastLoginAt: now
  };
  if (!snap.exists) {
    await ref.set({ ...base, createdAt: now, testsStartedByDay: {} }, { merge: true });
  } else {
    await ref.set(base, { merge: true });
  }
  if (approvedPremium) await admin.auth().setCustomUserClaims(uid, { admin: forcedPremium, premium: true });
  return (await ref.get()).data();
}

exports.syncUser = onCall(async (request) => {
  const auth = requireAuth(request);
  return { user: await getOrCreateUser(auth) };
});

exports.requestPremium = onCall(async (request) => {
  const auth = requireAuth(request);
  const email = normalizedEmail(auth);
  const user = await getOrCreateUser(auth);
  if (user.accountType === "premium") return { status: "already-premium" };
  const ref = db.collection("premiumRequests").doc(auth.uid);
  await ref.set({
    uid: auth.uid,
    email,
    displayName: auth.token.name || "",
    status: "pending",
    requestedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });
  return { status: "pending" };
});

exports.startTestSession = onCall(async (request) => {
  const auth = requireAuth(request);
  const userRef = db.collection("users").doc(auth.uid);
  const key = todayKey();
  return db.runTransaction(async (tx) => {
    const userSnap = await tx.get(userRef);
    if (!userSnap.exists) throw new HttpsError("failed-precondition", "User profile is missing.");
    const user = userSnap.data();
    const isPremium = user.accountType === "premium" || user.premiumStatus === "approved";
    const count = user.testsStartedByDay?.[key] || 0;
    if (!isPremium && count >= 1) {
      throw new HttpsError("resource-exhausted", "Basic accounts can take one test per day.");
    }
    tx.set(userRef, {
      [`testsStartedByDay.${key}`]: count + 1,
      lastTestStartedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });
    tx.set(db.collection("usage").doc(), {
      uid: auth.uid,
      email: user.email,
      type: "testStarted",
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
    return { ok: true, remainingToday: isPremium ? "unlimited" : 0 };
  });
});

exports.logUsage = onCall(async (request) => {
  const auth = requireAuth(request);
  const allowed = new Set(["testCompleted", "worksheetGenerated", "aiQuestionGeneration", "aiGrading"]);
  const type = allowed.has(request.data?.type) ? request.data.type : "unknown";
  await db.collection("usage").add({
    uid: auth.uid,
    email: normalizedEmail(auth),
    type,
    count: Number(request.data?.count || 1),
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
  return { ok: true };
});

exports.adminListDashboard = onCall(async (request) => {
  const auth = requireAuth(request);
  const email = normalizedEmail(auth);
  if (!isConfiguredAdmin(email)) throw new HttpsError("permission-denied", "Admin only.");
  const [usersSnap, requestsSnap, usageSnap] = await Promise.all([
    db.collection("users").orderBy("lastLoginAt", "desc").limit(200).get(),
    db.collection("premiumRequests").where("status", "==", "pending").orderBy("requestedAt", "desc").limit(100).get(),
    db.collection("usage").orderBy("createdAt", "desc").limit(500).get()
  ]);
  return {
    users: usersSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })),
    premiumRequests: requestsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })),
    usage: usageSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }))
  };
});

exports.adminSetPremium = onCall(async (request) => {
  const auth = requireAuth(request);
  const adminEmail = normalizedEmail(auth);
  if (!isConfiguredAdmin(adminEmail)) throw new HttpsError("permission-denied", "Admin only.");
  const uid = String(request.data?.uid || "");
  const approved = Boolean(request.data?.approved);
  if (!uid) throw new HttpsError("invalid-argument", "Missing user id.");
  await db.collection("users").doc(uid).set({
    accountType: approved ? "premium" : "basic",
    premiumStatus: approved ? "approved" : "denied",
    premiumDecidedAt: admin.firestore.FieldValue.serverTimestamp(),
    premiumDecidedBy: adminEmail
  }, { merge: true });
  await db.collection("premiumRequests").doc(uid).set({
    status: approved ? "approved" : "denied",
    decidedAt: admin.firestore.FieldValue.serverTimestamp(),
    decidedBy: adminEmail
  }, { merge: true });
  await admin.auth().setCustomUserClaims(uid, { premium: approved });
  await db.collection("adminAudit").add({
    adminEmail,
    action: approved ? "approvePremium" : "denyPremium",
    targetUid: uid,
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
  return { ok: true };
});

exports.generateWithOpenAI = onCall({ secrets: [OPENAI_API_KEY] }, async (request) => {
  const auth = requireAuth(request);
  const user = await getOrCreateUser(auth);
  const isPremium = user.accountType === "premium" || user.premiumStatus === "approved";
  const model = isPremium ? PREMIUM_MODEL.value() : BASIC_MODEL.value();
  const prompt = String(request.data?.prompt || "").slice(0, 6000);
  if (!prompt) throw new HttpsError("invalid-argument", "Missing prompt.");
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_API_KEY.value()}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model,
      input: prompt
    })
  });
  if (!response.ok) {
    const text = await response.text();
    throw new HttpsError("internal", `OpenAI request failed: ${text.slice(0, 500)}`);
  }
  const data = await response.json();
  await db.collection("usage").add({
    uid: auth.uid,
    email: user.email,
    type: "openaiCall",
    model,
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
  return { model, outputText: data.output_text || "" };
});
